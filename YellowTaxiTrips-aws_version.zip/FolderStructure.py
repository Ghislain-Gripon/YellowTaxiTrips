class FolderStructure:

    def __init__(self, environment:str, **kwargs):
        pass

    def Move_To_Directory(self, file_path, directory_name):
        pass

    def load(self, file_path):
        pass

    def read_yaml(self, file_stream):
        pass